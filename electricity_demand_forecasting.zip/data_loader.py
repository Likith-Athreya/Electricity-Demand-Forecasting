#!/usr/bin/env python3
"""
Data loader for smart meter and weather data.
Handles downloading and preprocessing of data from external sources.
"""

import pandas as pd
import numpy as np
import requests
import os
from datetime import datetime, timedelta
from pathlib import Path
import warnings

warnings.filterwarnings('ignore')

class DataLoader:
    """Handles data loading from various sources."""
    
    def __init__(self, data_dir="data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
    
    def download_kaggle_data(self, dataset_name="jehanbhathena/smart-meter-datamathura-and-bareilly"):
        """
        Download smart meter data from Kaggle.
        Note: Requires kaggle API credentials to be set up.
        """
        try:
            import kaggle
            print(f"Downloading dataset: {dataset_name}")
            
            # Download dataset
            kaggle.api.dataset_download_files(
                dataset_name, 
                path=self.data_dir, 
                unzip=True
            )
            
            print("Kaggle dataset downloaded successfully")
            return True
            
        except Exception as e:
            print(f"Warning: Could not download Kaggle data: {e}")
            print("Using synthetic data instead...")
            return False
    
    def load_smart_meter_data(self, city="Bareilly"):
        """Load smart meter data for specified city."""
        # Try to find the actual data file
        data_files = list(self.data_dir.glob("*.csv"))
        
        if not data_files:
            print("No data files found, generating synthetic data...")
            return self._generate_synthetic_data(city)
        
        # Load the first CSV file found
        data_file = data_files[0]
        print(f"Loading data from: {data_file}")
        
        try:
            df = pd.read_csv(data_file)
            
            # Process the data based on expected structure
            # This would need to be adapted based on actual data format
            if 'timestamp' in df.columns:
                df['timestamp'] = pd.to_datetime(df['timestamp'])
            else:
                # Create timestamp if not present
                df['timestamp'] = pd.date_range(
                    start='2024-01-01', 
                    periods=len(df), 
                    freq='3T'
                )
            
            # Filter for the specified city if city column exists
            if 'city' in df.columns:
                df = df[df['city'] == city]
            elif 'location' in df.columns:
                df = df[df['location'] == city]
            
            return df
            
        except Exception as e:
            print(f"Error loading data: {e}")
            print("Generating synthetic data instead...")
            return self._generate_synthetic_data(city)
    
    def _generate_synthetic_data(self, city="Bareilly"):
        """Generate synthetic smart meter data for demonstration."""
        print(f"Generating synthetic data for {city}...")
        
        # Generate 7 days of 3-minute data
        end_time = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        start_time = end_time - timedelta(days=7)
        
        timestamps = pd.date_range(start=start_time, end=end_time, freq='3T')
        
        # Create realistic demand pattern
        np.random.seed(42)
        
        # Base demand with daily and weekly seasonality
        hours = np.array([t.hour for t in timestamps])
        days = np.array([t.dayofweek for t in timestamps])
        
        # Daily pattern (higher during day, lower at night)
        daily_pattern = 50 + 40 * np.sin(2 * np.pi * hours / 24 - np.pi/2)
        
        # Weekly pattern (lower on weekends)
        weekly_pattern = 1 - 0.2 * (days >= 5).astype(int)
        
        # Add some noise
        noise = np.random.normal(0, 8, len(timestamps))
        
        # Combine patterns
        demand = daily_pattern * weekly_pattern + noise
        demand = np.maximum(demand, 5)  # Ensure positive values
        
        df = pd.DataFrame({
            'timestamp': timestamps,
            'demand_kwh': demand,
            'city': city
        })
        
        print(f"Generated {len(df)} synthetic readings")
        return df
    
    def get_weather_forecast(self, latitude=28.3640, longitude=79.4150, days=1):
        """Get weather forecast from Open-Meteo API."""
        print("Fetching weather forecast from Open-Meteo...")
        
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            'latitude': latitude,
            'longitude': longitude,
            'hourly': 'temperature_2m,relative_humidity_2m,precipitation',
            'forecast_days': days,
            'timezone': 'Asia/Kolkata'
        }
        
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            # Extract hourly data
            timestamps = pd.to_datetime(data['hourly']['time'])
            temperatures = data['hourly']['temperature_2m']
            humidity = data['hourly']['relative_humidity_2m']
            precipitation = data['hourly']['precipitation']
            
            weather_df = pd.DataFrame({
                'timestamp': timestamps,
                'temperature': temperatures,
                'humidity': humidity,
                'precipitation': precipitation
            })
            
            print(f"Retrieved weather data for {len(weather_df)} hours")
            return weather_df
            
        except Exception as e:
            print(f"Warning: Could not fetch weather data: {e}")
            return None
    
    def save_data(self, data, filename):
        """Save data to file."""
        filepath = self.data_dir / filename
        data.to_csv(filepath, index=False)
        print(f"Data saved to: {filepath}")
        return filepath

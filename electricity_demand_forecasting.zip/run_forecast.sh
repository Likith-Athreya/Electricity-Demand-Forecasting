#!/bin/bash

echo "24-Hour Electricity Demand Forecasting - Fast-Track Assessment"
echo "================================================================"
echo

# Install dependencies if needed
pip install -r requirements.txt

# Run the forecast
python run_forecast.py --city Bareilly --history_window days:7 --with_weather true --make_plots true --save_report true

echo
echo "================================================================"
echo "FORECASTING COMPLETE"
echo "================================================================"
echo "Check the following directories for outputs:"
echo "- artifacts/fast_track/ (forecast CSV, metrics, plots)"
echo "- reports/ (analysis report)"
echo "- results/ (additional results)"
echo

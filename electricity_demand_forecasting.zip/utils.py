#!/usr/bin/env python3
"""
Utility functions for electricity demand forecasting.
"""

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error
from typing import Tuple, Optional

def calculate_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    """
    Calculate evaluation metrics for forecasting.
    
    Args:
        y_true: Actual values
        y_pred: Predicted values
    
    Returns:
        Dictionary containing MAE, WAPE, and sMAPE
    """
    # Remove any NaN values
    mask = ~(np.isnan(y_true) | np.isnan(y_pred))
    y_true_clean = y_true[mask]
    y_pred_clean = y_pred[mask]
    
    if len(y_true_clean) == 0:
        return {'mae': np.nan, 'wape': np.nan, 'smape': np.nan}
    
    # Mean Absolute Error
    mae = mean_absolute_error(y_true_clean, y_pred_clean)
    
    # Weighted Absolute Percentage Error (WAPE)
    wape = np.abs(y_true_clean - y_pred_clean).sum() / y_true_clean.sum() * 100
    
    # Symmetric Mean Absolute Percentage Error (sMAPE)
    smape = np.mean(2 * np.abs(y_true_clean - y_pred_clean) / 
                   (np.abs(y_true_clean) + np.abs(y_pred_clean))) * 100
    
    return {
        'mae': mae,
        'wape': wape,
        'smape': smape
    }

def create_lag_features(data: pd.DataFrame, target_col: str, lags: list) -> pd.DataFrame:
    """
    Create lag features for time series data.
    
    Args:
        data: DataFrame with time series data
        target_col: Name of target column
        lags: List of lag periods to create
    
    Returns:
        DataFrame with lag features added
    """
    df = data.copy()
    
    for lag in lags:
        df[f'lag_{lag}'] = df[target_col].shift(lag)
    
    return df

def create_rolling_features(data: pd.DataFrame, target_col: str, windows: list) -> pd.DataFrame:
    """
    Create rolling window features.
    
    Args:
        data: DataFrame with time series data
        target_col: Name of target column
        windows: List of window sizes for rolling features
    
    Returns:
        DataFrame with rolling features added
    """
    df = data.copy()
    
    for window in windows:
        df[f'rolling_mean_{window}'] = df[target_col].rolling(window=window, min_periods=1).mean()
        df[f'rolling_std_{window}'] = df[target_col].rolling(window=window, min_periods=1).std()
    
    return df

def create_cyclical_features(data: pd.DataFrame, time_col: str) -> pd.DataFrame:
    """
    Create cyclical features from datetime column.
    
    Args:
        data: DataFrame with datetime column
        time_col: Name of datetime column
    
    Returns:
        DataFrame with cyclical features added
    """
    df = data.copy()
    dt = pd.to_datetime(df[time_col])
    
    # Hour features
    df['hour'] = dt.dt.hour
    df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
    df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
    
    # Day of week features
    df['day_of_week'] = dt.dt.dayofweek
    df['dow_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
    df['dow_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
    
    # Day of year features
    df['day_of_year'] = dt.dt.dayofyear
    df['doy_sin'] = np.sin(2 * np.pi * df['day_of_year'] / 365)
    df['doy_cos'] = np.cos(2 * np.pi * df['day_of_year'] / 365)
    
    return df

def detect_outliers_iqr(data: pd.Series, factor: float = 1.5) -> pd.Series:
    """
    Detect outliers using IQR method.
    
    Args:
        data: Time series data
        factor: IQR factor for outlier detection
    
    Returns:
        Boolean series indicating outliers
    """
    Q1 = data.quantile(0.25)
    Q3 = data.quantile(0.75)
    IQR = Q3 - Q1
    
    lower_bound = Q1 - factor * IQR
    upper_bound = Q3 + factor * IQR
    
    return (data < lower_bound) | (data > upper_bound)

def cap_outliers_percentile(data: pd.Series, upper_percentile: float = 99) -> pd.Series:
    """
    Cap outliers using percentile method.
    
    Args:
        data: Time series data
        upper_percentile: Upper percentile for capping
    
    Returns:
        Series with capped outliers
    """
    cap_value = data.quantile(upper_percentile / 100)
    return np.minimum(data, cap_value)

def seasonal_naive_forecast(data: pd.Series, horizon: int, season_length: int = 24) -> np.ndarray:
    """
    Generate seasonal naive forecast.
    
    Args:
        data: Historical time series data
        horizon: Forecast horizon
        season_length: Length of seasonal pattern
    
    Returns:
        Forecast values
    """
    if len(data) < season_length:
        # If not enough data, use last value
        return np.full(horizon, data.iloc[-1])
    
    # Use the same period from previous season
    last_season = data.iloc[-season_length:].values
    forecast = np.tile(last_season, (horizon // season_length + 1,))[:horizon]
    
    return forecast

def calculate_quantiles_from_residuals(residuals: np.ndarray, forecast: np.ndarray, 
                                     quantiles: list = [0.1, 0.5, 0.9]) -> dict:
    """
    Calculate quantile forecasts from residual distribution.
    
    Args:
        residuals: Historical residuals
        forecast: Point forecast
        quantiles: List of quantiles to calculate
    
    Returns:
        Dictionary with quantile forecasts
    """
    std_residual = np.std(residuals)
    
    quantile_forecasts = {}
    for q in quantiles:
        z_score = np.percentile(np.random.normal(0, 1, 10000), q * 100)
        quantile_forecasts[f'p{int(q*100)}'] = forecast + z_score * std_residual
    
    return quantile_forecasts

def validate_forecast_inputs(data: pd.DataFrame, required_cols: list) -> bool:
    """
    Validate that required columns exist in data.
    
    Args:
        data: DataFrame to validate
        required_cols: List of required column names
    
    Returns:
        True if all required columns exist
    """
    missing_cols = [col for col in required_cols if col not in data.columns]
    
    if missing_cols:
        print(f"Warning: Missing required columns: {missing_cols}")
        return False
    
    return True

def format_forecast_output(forecast_df: pd.DataFrame, 
                          timestamp_col: str = 'timestamp',
                          forecast_col: str = 'yhat') -> pd.DataFrame:
    """
    Format forecast output for submission.
    
    Args:
        forecast_df: DataFrame with forecast data
        timestamp_col: Name of timestamp column
        forecast_col: Name of forecast column
    
    Returns:
        Formatted forecast DataFrame
    """
    output_cols = [timestamp_col, forecast_col]
    
    # Add quantile columns if they exist
    quantile_cols = [col for col in forecast_df.columns if col.startswith('y_p')]
    output_cols.extend(sorted(quantile_cols))
    
    return forecast_df[output_cols].copy()

#!/usr/bin/env python3
"""
Test script to demonstrate the forecasting functionality.
"""

import subprocess
import sys
from pathlib import Path

def test_forecast():
    """Test the forecasting functionality."""
    print("Testing 24-Hour Electricity Demand Forecasting")
    print("=" * 50)
    
    # Test different configurations
    test_cases = [
        {
            "name": "Basic forecast with weather",
            "args": ["--city", "Bareilly", "--with_weather", "true", "--make_plots", "true"]
        },
        {
            "name": "Forecast without weather",
            "args": ["--city", "Bareilly", "--with_weather", "false", "--make_plots", "true"]
        }
    ]
    
    for test_case in test_cases:
        print(f"\nRunning: {test_case['name']}")
        print("-" * 30)
        
        try:
            # Run the forecast
            cmd = [sys.executable, "run_forecast.py"] + test_case["args"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                print("✓ Test passed")
                
                # Check if outputs were created
                artifacts_dir = Path("artifacts/fast_track")
                if artifacts_dir.exists():
                    files = list(artifacts_dir.glob("*"))
                    print(f"  Generated {len(files)} artifact files")
                
                reports_dir = Path("reports")
                if reports_dir.exists():
                    files = list(reports_dir.glob("*"))
                    print(f"  Generated {len(files)} report files")
                    
            else:
                print("✗ Test failed")
                print(f"Error: {result.stderr}")
                
        except subprocess.TimeoutExpired:
            print("✗ Test timed out")
        except Exception as e:
            print(f"✗ Test error: {e}")
    
    print("\n" + "=" * 50)
    print("Testing complete!")

if __name__ == "__main__":
    test_forecast()

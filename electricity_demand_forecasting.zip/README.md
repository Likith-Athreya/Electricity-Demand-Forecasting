# 24-Hour Electricity Demand Forecasting - Fast-Track Assessment

This project implements a complete electricity demand forecasting solution for Bareilly, India, using smart-meter data and optional weather information.

## Project Structure

```
assignment/
├── run_forecast.py          # Main execution script
├── data_loader.py           # Data loading utilities
├── utils.py                 # Utility functions
├── requirements.txt         # Python dependencies
├── README.md               # This file
├── artifacts/              # Generated outputs
│   └── fast_track/
│       ├── forecast_T_plus_24.csv
│       ├── metrics.csv
│       └── plots/
├── reports/                # Generated reports
│   └── fast_track_report.md
└── results/                # Additional results
```

## Quick Start

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the Forecast**
   ```bash
   python run_forecast.py --city Bareilly --history_window days:7 --with_weather true --make_plots true --save_report true
   ```

## Features

### Data Processing
- **Smart Meter Data**: 3-minute readings aggregated to hourly
- **Gap Handling**: Conservative forward-fill imputation
- **Outlier Treatment**: 99th percentile capping with audit trail
- **Weather Integration**: Open-Meteo API for temperature forecasts

### Models
- **Baseline**: Seasonal naive (same hour from previous day)
- **ML Model**: Ridge regression with engineered features
- **Features**: Hour-of-day, day-of-week, lags, rolling means, temperature

### Evaluation Metrics
- **MAE**: Mean Absolute Error
- **WAPE**: Weighted Absolute Percentage Error
- **sMAPE**: Symmetric Mean Absolute Percentage Error

### Outputs
- **Forecast CSV**: 24-hour ahead predictions with confidence intervals
- **Metrics**: Model performance comparison
- **Plots**: 3-day actuals + forecast overlay, horizon-wise MAE
- **Report**: 2-page professional analysis

## Command Line Interface

```bash
python run_forecast.py [OPTIONS]

Options:
  --city TEXT              City name (default: Bareilly)
  --history_window TEXT    History window (default: days:7)
  --with_weather BOOLEAN   Include weather data (default: true)
  --make_plots BOOLEAN     Generate plots (default: true)
  --save_report BOOLEAN    Save report (default: true)
```

## Data Sources

- **Demand Data**: [Kaggle Smart Meter Dataset](https://www.kaggle.com/datasets/jehanbhathena/smart-meter-datamathura-and-bareilly)
- **Weather Data**: [Open-Meteo API](https://open-meteo.com/en/docs)

## Methodology

### Data Preparation
1. Resample 3-minute data to hourly by summing
2. Handle gaps with forward-fill imputation
3. Cap outliers at 99th percentile
4. Merge weather data by timestamp

### Feature Engineering
- Cyclical encoding for time features (sin/cos)
- Lag features (1, 2, 3 hours)
- Rolling statistics (24-hour mean)
- Weather variables (temperature)

### Model Training
- **Baseline**: Seasonal naive using 24-hour lag
- **ML Model**: Ridge regression with regularization
- **Validation**: Time-series aware evaluation

### Forecasting
- Generate 24-hour ahead predictions
- Calculate confidence intervals from residuals
- Provide quantile forecasts (10th, 50th, 90th percentiles)

## Output Files

### Forecast Output (`forecast_T_plus_24.csv`)
```csv
timestamp,yhat,y_p10,y_p50,y_p90
2024-01-08 01:00:00,45.2,38.1,45.2,52.3
2024-01-08 02:00:00,42.1,35.0,42.1,49.2
...
```

### Metrics (`metrics.csv`)
```csv
Model,MAE,WAPE,sMAPE
Baseline (Seasonal Naive),8.45,12.3,15.2
ML Model (Ridge),7.23,10.8,13.1
```

## Plots

1. **Forecast Overlay**: Last 3 days of actual demand with 24-hour forecast
2. **Horizon-wise MAE**: Error analysis across forecast horizons

## Report

The generated report includes:
- Problem statement and methodology
- Data preparation steps
- Model performance comparison
- Key takeaways and next steps

## Reproducibility

The solution is designed for reproducibility with:
- Single command execution
- Deterministic random seeds
- Documented data handling
- Version-controlled dependencies

## Requirements

- Python 3.8+
- pandas, numpy, scikit-learn
- matplotlib, seaborn
- requests (for weather API)

## Notes

- Uses synthetic data if Kaggle dataset is unavailable
- Weather data is optional but recommended
- All outputs are saved to predictable locations
- Code includes comprehensive error handling

## License

This project is for educational and assessment purposes.
